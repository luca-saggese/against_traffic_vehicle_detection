This folder contains 2 .py files which support to find the centroid of the detected rectangular and attach the ID to the detected objects
